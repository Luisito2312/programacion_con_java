package clases;

public interface MascotaInterface {
  
  public static void pasear(){
  }
}
